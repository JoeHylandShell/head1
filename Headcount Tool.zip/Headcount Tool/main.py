"""
================================================================================
HEADCOUNT LIST AUTOMATION SYSTEM
================================================================================

Purpose:
    Automates monthly headcount reconciliation for Shell Trading & Supply
    Market Risk Analytics team. Compares HR export against SharePoint headcount
    list and generates a detailed change report.

Author: Joe Hyland
Team: Market Risk Analytics - Governance Risk
Date: April 2026

Main Features:
    - Filters HR export to relevant supervisory codes (FST, FO/AM, FO/UCT)
    - Applies location-based Management Level overrides for FO employees
    - Compares HR data with SharePoint to identify leavers, joiners, and updates
    - Generates formatted Excel report with color-coded tabs
    - Handles hardcoded exceptions for specific employees
================================================================================
"""

import pandas as pd
from datetime import datetime
import sys
import re

# ============================================================================
# CONFIGURATION
# ============================================================================

# FO Location Override Mapping
# Maps employee locations to their correct Management Level values
# These override generic HR codes (like "04", "05") with specific SBO values
FO_LOCATION_OVERRIDES_RAW = {
    'SHELL CENTRE – CHENNAI': 'SBO Chennai',
    'Dela Rosa - Street office': 'SBO Philippines',
    'Cyberjaya-Wisma Shell': 'SBO Malaysia',
    'Bangalore RMZ-ECO WORLD': 'SBO Bangalore',
    'Bangkok': 'SBO Thailand',
    'Shell Business Operations-DOT': 'SBO Poland'
}

# Hardcoded email exceptions
# These employees are always included regardless of supervisory code
# Needed when employees change teams/codes but should still be tracked
ALWAYS_INCLUDE_EMAILS = [
    'Rejoice.John@shell.com',
    'Bryan.Acosta@shell.com'
]


# ============================================================================
# TEXT NORMALIZATION FUNCTIONS
# ============================================================================

def normalize_location(location):
    """
    Normalize location strings for reliable matching.
    
    Handles various formatting inconsistencies in location data:
    - Different dash types (en-dash –, em-dash —, hyphen -)
    - Multiple spaces
    - Case differences
    
    Args:
        location (str): Raw location string from Excel
        
    Returns:
        str: Normalized location string (lowercase, single spaces, standard hyphens)
        
    Example:
        "SHELL  CENTRE – CHENNAI" → "shell centre - chennai"
    """
    if not location:
        return ''
    
    # Convert to string and lowercase
    normalized = str(location).lower().strip()
    
    # Replace all dash variants with standard hyphen
    # Different systems use different dash characters, need to handle all
    dash_variants = ['–', '—', '−', '‒', '‑', '­']
    for dash in dash_variants:
        normalized = normalized.replace(dash, '-')
    
    # Replace multiple spaces with single space
    normalized = re.sub(r'\s+', ' ', normalized)
    
    return normalized


def normalize_text(text):
    """
    Normalize any text for comparison to avoid false positives.
    
    Used when comparing fields between HR export and SharePoint to ensure
    formatting differences don't trigger unnecessary change alerts.
    
    Args:
        text: Any text value from Excel (string, number, or NaN)
        
    Returns:
        str: Normalized text string
        
    Example:
        "John  Smith" → "john smith"
        NaN → ""
    """
    if not text or pd.isna(text):
        return ''
    
    # Convert to string and lowercase
    normalized = str(text).lower().strip()
    
    # Replace various dash characters with standard hyphen
    dash_variants = ['–', '—', '−', '‒', '‑', '­']
    for dash in dash_variants:
        normalized = normalized.replace(dash, '-')
    
    # Replace multiple spaces with single space
    normalized = re.sub(r'\s+', ' ', normalized)
    
    return normalized


# Create normalized FO override lookup dictionary
# Pre-normalize all location keys for faster matching
FO_LOCATION_OVERRIDES = {
    normalize_location(loc): value 
    for loc, value in FO_LOCATION_OVERRIDES_RAW.items()
}


# ============================================================================
# FO OVERRIDE LOGIC
# ============================================================================

def apply_fo_overrides(df, supervisory_col, location_col, management_col):
    """
    Apply Management Level overrides for FO employees based on location.
    
    Business Rule:
        Employees with supervisory codes starting with "FO" should have their
        Management Level determined by their location, not the generic codes
        from the HR system.
    
    Process:
        1. Find all employees with FO supervisory codes
        2. Check their location
        3. If location matches override table, replace Management Level
        4. Track and report all overrides applied
    
    Args:
        df (DataFrame): Employee data to process
        supervisory_col (str): Column name for supervisory codes
        location_col (str): Column name for employee locations
        management_col (str): Column name for management levels
        
    Returns:
        DataFrame: Modified DataFrame with overrides applied
        
    Side Effects:
        Prints override details to console for verification
    """
    # Make a copy to avoid modifying original DataFrame
    df = df.copy()
    
    # Track how many overrides we apply
    override_count = 0
    
    print(f"\nChecking for FO overrides...")
    print(f"  Supervisory column: {supervisory_col}")
    print(f"  Location column: {location_col}")
    print(f"  Management Level column: {management_col}")
    
    # Iterate through each row looking for FO supervisory codes
    for idx, row in df.iterrows():
        supervisory_code = str(row.get(supervisory_col, '')).strip()
        
        # Only process rows with FO supervisory codes
        if supervisory_code.startswith('FO'):
            location = str(row.get(location_col, '')).strip()
            location_normalized = normalize_location(location)
            
            # Check if normalized location matches any override rule
            if location_normalized in FO_LOCATION_OVERRIDES:
                new_management_level = FO_LOCATION_OVERRIDES[location_normalized]
                old_management_level = str(row.get(management_col, '')).strip()
                
                # Apply the override
                df.at[idx, management_col] = new_management_level
                override_count += 1
                
                # Only print if value actually changed (for debugging)
                if old_management_level != new_management_level:
                    print(f"  Override: {supervisory_code} at {location} → {new_management_level} (was {old_management_level})")
    
    # Print summary
    if override_count > 0:
        print(f"\n✓ Applied {override_count} FO location overrides")
    else:
        print(f"\n⚠ No FO overrides applied (no matching FO codes + locations found)")
    
    return df


# ============================================================================
# FILE READING AND FILTERING
# ============================================================================

def read_and_filter_excel(hr_file_path, sharepoint_file_path):
    """
    Read HR and SharePoint exports, filter to relevant employees, apply overrides.
    
    This is the main data ingestion function. It:
        1. Reads both Excel files
        2. Filters HR export to only relevant supervisory codes
        3. Adds hardcoded email exceptions
        4. Applies FO location overrides
    
    Args:
        hr_file_path (str): Full path to HR export Excel file
        sharepoint_file_path (str): Full path to SharePoint export Excel file
        
    Returns:
        tuple: (filtered_hr_df, sharepoint_df)
            - filtered_hr_df: HR data filtered and with overrides applied
            - sharepoint_df: Raw SharePoint data (unfiltered)
            
    Raises:
        SystemExit: If files cannot be read or required columns missing
    """
    print(f"\nReading HR export: {hr_file_path}")
    print(f"Reading SharePoint export: {sharepoint_file_path}")
    
    try:
        # Read both Excel files
        # Assumes first sheet contains the data (or only one sheet exists)
        hr_df = pd.read_excel(hr_file_path)
        sharepoint_df = pd.read_excel(sharepoint_file_path)
        
        print(f"✓ Read HR export: {len(hr_df)} rows")
        print(f"✓ Read SharePoint export: {len(sharepoint_df)} rows")
        
        # Display column names for debugging
        print(f"\nColumns in HR export:")
        for i, col in enumerate(hr_df.columns, 1):
            print(f"  {i}. {col}")
        
        # Find supervisory code column
        # Try common variations of column names
        supervisory_col = None
        if 'Supervisory Code' in hr_df.columns:
            supervisory_col = 'Supervisory Code'
        elif 'Supervisory Organization Code' in hr_df.columns:
            supervisory_col = 'Supervisory Organization Code'
        else:
            print("\n⚠ Warning: Could not find supervisory code column!")
            print("Available columns:", list(hr_df.columns))
            return hr_df, sharepoint_df
        
        # ====================================================================
        # FILTERING: Keep only employees from specific teams
        # ====================================================================
        # FST = Fiona Grandison's team
        # FO/AM = Rejoice John's team  
        # FO/UCT = Bryan Acosta's team
        print(f"\nFiltering by '{supervisory_col}'...")
        filtered_df = hr_df[
            hr_df[supervisory_col].astype(str).str.startswith('FST') |
            hr_df[supervisory_col].astype(str).str.startswith('FO/AM') |
            (hr_df[supervisory_col].astype(str) == 'FO/UCT')
        ].copy()
        
        print(f"✓ Filtered from {len(hr_df)} to {len(filtered_df)} records")
        
        # ====================================================================
        # ADD HARDCODED EXCEPTIONS
        # ====================================================================
        # Some employees need to be tracked even if their supervisory code
        # doesn't match (e.g., when they change teams)
        
        # Find email column (used as unique identifier)
        email_col = None
        for col in hr_df.columns:
            if 'email' in col.lower():
                email_col = col
                break
        
        if email_col:
            # Add each exception email if not already in filtered set
            for exception_email in ALWAYS_INCLUDE_EMAILS:
                # Check if already included
                already_included = filtered_df[email_col].str.lower().str.strip().eq(exception_email.lower()).any()
                
                if not already_included:
                    # Find them in the full HR export
                    exception_rows = hr_df[hr_df[email_col].str.lower().str.strip() == exception_email.lower()]
                    if not exception_rows.empty:
                        # Add to filtered dataset
                        filtered_df = pd.concat([filtered_df, exception_rows], ignore_index=True)
                        print(f"  ✓ Added exception: {exception_email}")
        
        print(f"✓ Final count after exceptions: {len(filtered_df)} records")
        
        # ====================================================================
        # APPLY FO LOCATION OVERRIDES
        # ====================================================================
        # Find location and management level columns
        location_col = None
        management_col = None
        
        for col in filtered_df.columns:
            if 'location' in col.lower():
                location_col = col
                break
        
        for col in filtered_df.columns:
            if 'management' in col.lower() and 'level' in col.lower():
                management_col = col
                break
        
        if location_col and management_col:
            print(f"\nApplying FO location overrides...")
            filtered_df = apply_fo_overrides(filtered_df, supervisory_col, location_col, management_col)
        else:
            # Warn if override can't be applied (missing columns)
            print(f"\n⚠ Warning: Could not find location/management columns for FO overrides")
            if not location_col:
                print("  Missing: Location column")
            if not management_col:
                print("  Missing: Management Level column")
        
        return filtered_df, sharepoint_df
        
    except Exception as e:
        print(f"\n❌ Error reading Excel files: {e}")
        sys.exit(1)


# ============================================================================
# DATA COMPARISON
# ============================================================================

def compare_data(lookup_df, headcount_df):
    """
    Compare HR export with SharePoint to identify changes.
    
    Uses email addresses as the unique identifier to match people across
    both datasets. Identifies three types of changes:
        1. New joiners (in HR but not SharePoint)
        2. Leavers (in SharePoint but not HR)
        3. Updates (in both, but with field differences)
    
    Args:
        lookup_df (DataFrame): Filtered HR data (with overrides applied)
        headcount_df (DataFrame): Current SharePoint data
        
    Returns:
        dict: Dictionary containing:
            - 'to_add': DataFrame of new joiners
            - 'to_remove': DataFrame of leavers
            - 'to_update': DataFrame of field changes
            
    Business Logic:
        - Comparison uses lowercase, trimmed email addresses
        - Field changes ignore formatting differences (spaces, dashes, decimals)
        - FTE values normalized (100.0 = 1.0)
        - Only meaningful changes are reported
    """
    print("\nComparing data...")
    
    # Find email column (used as unique identifier)
    email_col = None
    for col in lookup_df.columns:
        if 'email' in col.lower():
            email_col = col
            break
    
    if not email_col:
        print("❌ Error: Could not find email column!")
        return {
            'to_add': pd.DataFrame(),
            'to_remove': pd.DataFrame(),
            'to_update': pd.DataFrame()
        }
    
    print(f"  Using '{email_col}' as unique identifier")
    
    # ========================================================================
    # CREATE SETS OF EMAILS FOR COMPARISON
    # ========================================================================
    # Normalize emails (lowercase, trimmed) to avoid false mismatches
    lookup_emails = set(lookup_df[email_col].dropna().astype(str).str.strip().str.lower())
    headcount_emails = set(headcount_df[email_col].dropna().astype(str).str.strip().str.lower())
    
    # Debug output
    print(f"\n  Lookup File (HR export): {len(lookup_emails)} unique emails")
    print(f"  Headcount List (SharePoint): {len(headcount_emails)} unique emails")
    
    # Find differences using set operations
    to_add_emails = lookup_emails - headcount_emails  # In HR but not SharePoint
    to_remove_emails = headcount_emails - lookup_emails  # In SharePoint but not HR
    common_emails = lookup_emails & headcount_emails  # In both
    
    print(f"\n  New joiners (in HR but not SharePoint): {len(to_add_emails)}")
    print(f"  Leavers (in SharePoint but not HR): {len(to_remove_emails)}")
    print(f"  Existing employees (in both): {len(common_emails)}")
    
    # Show leavers for debugging (helps catch issues like Rejoice/Bryan)
    if to_remove_emails and len(to_remove_emails) <= 20:
        print(f"\n  Leaver emails (NOT in HR export):")
        for email in sorted(list(to_remove_emails))[:20]:
            print(f"    - {email}")
    
    # Show sample of new joiners if any
    if to_add_emails and len(to_add_emails) <= 10:
        print(f"\n  New joiner emails:")
        for email in list(to_add_emails)[:10]:
            print(f"    - {email}")
    
    # ========================================================================
    # CREATE NEW JOINERS DATAFRAME
    # ========================================================================
    to_add = lookup_df[lookup_df[email_col].astype(str).str.strip().str.lower().isin(to_add_emails)].copy()
    
    # ========================================================================
    # CREATE LEAVERS DATAFRAME (SIMPLIFIED)
    # ========================================================================
    # For leavers, we only need name, email, and action
    # No need for full employee details
    leavers_full = headcount_df[headcount_df[email_col].astype(str).str.strip().str.lower().isin(to_remove_emails)].copy()
    
    leavers_records = []
    for _, row in leavers_full.iterrows():
        # Try to find name column (try multiple variations)
        name = ''
        for name_col in ['Employee Name', 'Full Name', 'Name', 'Employee Middle Name', 'User Name']:
            if name_col in row.index and pd.notna(row[name_col]) and str(row[name_col]).strip():
                name = str(row[name_col]).strip()
                break
        
        # If still no name found, try any non-empty text column
        if not name:
            for col in leavers_full.columns:
                if col != email_col and pd.notna(row[col]):
                    val = str(row[col]).strip()
                    # Check if it looks like a name (has spaces, not too long, not all caps)
                    if ' ' in val and len(val) < 50 and not val.isupper():
                        name = val
                        break
        
        leavers_records.append({
            'Name': name if name else 'Unknown',
            'Email': row[email_col],
            'Action': 'Mark as LEFT in SharePoint'
        })
    
    to_remove = pd.DataFrame(leavers_records) if leavers_records else pd.DataFrame()
    
    # ========================================================================
    # CREATE UPDATES DATAFRAME (FIELD-BY-FIELD CHANGES)
    # ========================================================================
    # For people in both systems, check each field for changes
    update_records = []
    
    for email in common_emails:
        # Get the row for this person from each system
        lookup_row = lookup_df[lookup_df[email_col].astype(str).str.strip().str.lower() == email].iloc[0]
        headcount_row = headcount_df[headcount_df[email_col].astype(str).str.strip().str.lower() == email].iloc[0]
        
        # Check each field for changes
        for col in lookup_df.columns:
            if col in headcount_df.columns and col != email_col:  # Don't compare email with itself
                old_value = str(headcount_row[col]).strip()
                new_value = str(lookup_row[col]).strip()
                
                # Normalize both values for comparison
                old_normalized = normalize_text(old_value)
                new_normalized = normalize_text(new_value)
                
                # ============================================================
                # VALUE NORMALIZATION FUNCTION
                # ============================================================
                # Handles special cases like FTE percentages and decimal formatting
                def normalize_value(val, column_name):
                    """
                    Normalize values to avoid false positives from formatting.
                    
                    Special Cases:
                        - FTE fields: 100.0 and 1.0 both mean 100% (normalize to decimal)
                        - Decimals: 299758.0 and 299758 are the same (remove .0)
                    
                    Args:
                        val (str): Value to normalize
                        column_name (str): Column name (to detect FTE fields)
                        
                    Returns:
                        str: Normalized value
                    """
                    try:
                        # Special handling for FTE column: 100.0 and 1.0 are the same
                        if 'FTE' in column_name.upper():
                            num_val = float(val)
                            # Normalize to decimal form (1.0 = 100%)
                            if num_val > 1.5:  # If it's 100 or higher, convert to decimal
                                return str(num_val / 100.0)
                            else:
                                return str(num_val)
                        
                        # If it's a number with .0, remove the decimal
                        if '.' in val and float(val) == int(float(val)):
                            return str(int(float(val)))
                        return val
                    except (ValueError, OverflowError):
                        return val
                
                old_normalized = normalize_value(old_normalized, col)
                new_normalized = normalize_value(new_normalized, col)
                
                # Only record if actually different after normalization
                if old_normalized != new_normalized:
                    # Try to get name for readability
                    name = ''
                    for name_col in ['Employee Name', 'Full Name', 'Name', 'Employee Middle Name']:
                        if name_col in lookup_row.index:
                            name = str(lookup_row[name_col])
                            break
                    
                    update_records.append({
                        'Name': name,
                        'Email': lookup_row[email_col],
                        'Field Changed': col,
                        'Old Value': old_value,
                        'New Value': new_value
                    })
    
    to_update = pd.DataFrame(update_records) if update_records else pd.DataFrame()
    
    # Print summary statistics
    print(f"\n  Summary:")
    print(f"  - New joiners: {len(to_add)}")
    print(f"  - Leavers: {len(to_remove)}")
    print(f"  - Field changes: {len(to_update)} (across {len(set(to_update['Email']) if not to_update.empty else [])} employees)")
    
    return {
        'to_add': to_add,
        'to_remove': to_remove,
        'to_update': to_update
    }


# ============================================================================
# REPORT GENERATION
# ============================================================================

def generate_report(changes, output_path):
    """
    Generate formatted Excel report with color-coded tabs.
    
    Creates a professional Excel workbook with:
        - Summary tab (overview and timestamp)
        - 1_New_Additions tab (green) - new joiners
        - 2_Leavers tab (red) - people who left
        - 3_Updates tab (yellow) - field changes
    
    Features:
        - Frozen header rows
        - Alternating row colors
        - Auto-adjusted column widths
        - Color-coded tab names
        - Filters on headers
        - Professional formatting
    
    Args:
        changes (dict): Dictionary from compare_data() containing:
            - 'to_add': New joiners DataFrame
            - 'to_remove': Leavers DataFrame
            - 'to_update': Updates DataFrame
        output_path (str): Full path for output Excel file
        
    Side Effects:
        - Creates Excel file at output_path
        - Prints success message with path
    """
    print(f"\nGenerating report: {output_path}")
    
    # Create Excel writer
    writer = pd.ExcelWriter(output_path, engine='openpyxl')
    
    # Get dataframes
    to_add = changes['to_add']
    to_remove = changes['to_remove']
    to_update = changes['to_update']
    
    # ========================================================================
    # SUMMARY TAB
    # ========================================================================
    summary_data = {
        'Category': ['New Additions', 'Leavers', 'Updates', 'Report Generated'],
        'Count': [
            len(to_add),
            len(to_remove),
            len(to_update),
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ]
    }
    summary_df = pd.DataFrame(summary_data)
    summary_df.to_excel(writer, sheet_name='Summary', index=False)
    
    # ========================================================================
    # NEW ADDITIONS TAB (if any)
    # ========================================================================
    if not to_add.empty:
        to_add.to_excel(writer, sheet_name='1_New_Additions', index=False)
    
    # ========================================================================
    # LEAVERS TAB (if any)
    # ========================================================================
    if not to_remove.empty:
        to_remove.to_excel(writer, sheet_name='2_Leavers', index=False)
    
    # ========================================================================
    # UPDATES TAB (if any)
    # ========================================================================
    if not to_update.empty:
        to_update.to_excel(writer, sheet_name='3_Updates', index=False)
    
    # Save the workbook
    writer.close()
    
    # ========================================================================
    # APPLY FORMATTING
    # ========================================================================
    # Reopen to apply professional formatting
    from openpyxl import load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    
    wb = load_workbook(output_path)
    
    # Format each worksheet
    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        
        # Skip if sheet is empty
        if ws.max_row <= 1:
            continue
        
        # Freeze top row (header)
        ws.freeze_panes = 'A2'
        
        # Format header row (dark blue background, white text, bold)
        header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
        header_font = Font(bold=True, color="FFFFFF", size=11)
        
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Alternating row colors (light gray for even rows)
        gray_fill = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, max_row=ws.max_row), start=2):
            if row_idx % 2 == 0:
                for cell in row:
                    cell.fill = gray_fill
        
        # Auto-adjust column widths
        for col_idx, column in enumerate(ws.columns, start=1):
            max_length = 0
            column_letter = get_column_letter(col_idx)
            
            for cell in column:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            
            # Set column width (add padding)
            adjusted_width = min(max_length + 2, 50)  # Cap at 50 for readability
            ws.column_dimensions[column_letter].width = adjusted_width
        
        # Enable filters on header row
        ws.auto_filter.ref = ws.dimensions
    
    # Color-code tab names
    if '1_New_Additions' in wb.sheetnames:
        wb['1_New_Additions'].sheet_properties.tabColor = "00B050"  # Green
    if '2_Leavers' in wb.sheetnames:
        wb['2_Leavers'].sheet_properties.tabColor = "FF0000"  # Red
    if '3_Updates' in wb.sheetnames:
        wb['3_Updates'].sheet_properties.tabColor = "FFC000"  # Yellow
    
    # Save formatted workbook
    wb.save(output_path)
    
    print(f"✓ Report generated successfully")


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Main execution function - orchestrates the entire workflow.
    
    Workflow:
        1. Get file paths from user (HR export + SharePoint export)
        2. Read and filter data (apply overrides and exceptions)
        3. Compare data to find changes
        4. Generate formatted Excel report
        5. Display success message
    
    User Interaction:
        Prompts for two file paths via console input
        
    Exit Codes:
        0: Success
        1: Error (file not found, missing columns, etc.)
    """
    print("="*60)
    print("HEADCOUNT LIST AUTOMATION - WITH FO OVERRIDES")
    print("="*60)
    
    # Get file paths from user
    print("\nPlease provide the following files:")
    hr_file = input("1. HR Export file path: ").strip().strip('"')
    sharepoint_file = input("2. SharePoint Export file path: ").strip().strip('"')
    
    # Read and filter data
    hr_df, sharepoint_df = read_and_filter_excel(hr_file, sharepoint_file)
    
    # Compare data
    changes = compare_data(hr_df, sharepoint_df)
    
    # Generate report
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = f"Headcount_Changes_Report_{timestamp}.xlsx"
    generate_report(changes, output_path)
    
    # Success message
    print("\n" + "="*60)
    print("COMPLETE!")
    print("="*60)
    print(f"\nReport saved to: {output_path}")
    print("\nNext steps:")
    print("1. Open the report and review the changes")
    print("2. Update SharePoint based on the report")
    print("="*60)


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    main()
