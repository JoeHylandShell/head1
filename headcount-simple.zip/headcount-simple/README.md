# Headcount List Automation - SIMPLE VERSION

No SharePoint authentication. No cookies. No bullshit.

## What it does:

1. Reads your Excel file (both "Lookup File JH" and "Headcount List JH" worksheets)
2. Compares them
3. Generates an Excel report showing what needs to change
4. You manually update SharePoint based on the report

## Setup (5 minutes):

```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt
```

## Usage:

```bash
python main.py
```

It will ask you for the Excel file path. Paste it and press Enter.

**Example:**
```
Enter the full path to your Excel file: C:/Users/joseph.hyland/Downloads/Headcount List - Reconciliation File From Apr 2025.xlsx
```

## Output:

You'll get an Excel file called `Headcount_Changes_Report_YYYYMMDD_HHMMSS.xlsx` with:

- **Summary** - Overview of changes
- **1_To_Add** - New records to add to SharePoint
- **2_To_Remove** - Records to mark as "Left" 
- **3_To_Update** - Records with changed fields

## That's it!

No authentication. No cookies. Just works.
