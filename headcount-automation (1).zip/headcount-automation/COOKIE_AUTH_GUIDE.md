# Cookie Authentication Guide

This guide explains how to use browser cookies for SharePoint authentication (works with MFA!).

## Why Use Cookies?

If your Shell account has Multi-Factor Authentication (MFA) enabled, you can't use username/password directly. Instead, you can use your browser's authentication cookies.

## Step-by-Step Instructions

### Step 1: Log into SharePoint in Your Browser

1. Open Chrome or Edge
2. Go to your SharePoint Headcount List
3. Make sure you're fully logged in and can see the list

### Step 2: Get Your Cookies

#### In Chrome:
1. Press **F12** (or right-click → Inspect)
2. Go to the **Application** tab at the top
3. In the left sidebar, expand **Cookies**
4. Click on `https://shell.sharepoint.com`
5. Find these two cookies and copy their **Value**:
   - `FedAuth`
   - `rtFa`

#### In Edge:
1. Press **F12**
2. Go to **Application** tab
3. Same as Chrome above

### Step 3: Add Cookies to .env File

Open your `.env` file and update it:

```env
# SharePoint Configuration
SHAREPOINT_URL=https://shell.sharepoint.com

# Enable cookie authentication
USE_COOKIES=true

# Paste your cookie values here (long strings)
FEDAUTH_COOKIE=0.ARoAexAM... (paste FedAuth value)
RTFA_COOKIE=0x1234... (paste rtFa value)

# You can leave username/password blank when using cookies
SHAREPOINT_USERNAME=
SHAREPOINT_PASSWORD=

# Rest of your config...
HEADCOUNT_LIST_URL=https://shell.sharepoint.com/sites/...
LOOKUP_FILE_PATH=C:/Users/joseph.hyland/...
```

### Step 4: Run the Automation

```powershell
python main.py
```

## Important Notes

⚠️ **Cookies expire!** Usually after 24 hours or when you log out. If the script stops working, just get fresh cookies.

⚠️ **Keep cookies secret!** They're like temporary passwords. Don't share your `.env` file.

✅ **Pro tip:** If you need to run this regularly, just grab fresh cookies each time before running the script.

## Troubleshooting

**"Authentication failed"**
→ Get fresh cookies from your browser

**"Cookie not found"**
→ Make sure you copied both FedAuth AND rtFa cookies

**Still not working?**
→ Make sure `USE_COOKIES=true` (not false)
→ Make sure you're logged into the correct Shell SharePoint site in your browser
