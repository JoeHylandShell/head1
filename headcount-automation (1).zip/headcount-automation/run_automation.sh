#!/bin/bash
# Headcount List Automation - Mac/Linux Run Script

echo "============================================"
echo "Headcount List Automation"
echo "============================================"
echo ""

# Activate virtual environment
if [ -f venv/bin/activate ]; then
    source venv/bin/activate
    echo "Virtual environment activated"
else
    echo "Warning: Virtual environment not found"
    echo "Please run: python -m venv venv"
    echo ""
fi

# Run the automation
echo "Running automation..."
echo ""
python main.py

# Check exit code
if [ $? -eq 0 ]; then
    echo ""
    echo "============================================"
    echo "Automation completed successfully!"
    echo "============================================"
else
    echo ""
    echo "============================================"
    echo "Automation failed with errors"
    echo "Check logs/headcount_sync.log for details"
    echo "============================================"
fi

echo ""
