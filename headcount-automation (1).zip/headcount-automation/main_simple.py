"""
Headcount List Automation - SIMPLIFIED VERSION (No SharePoint Auth)

This version:
- Reads both worksheets from the Excel file
- Compares them
- Generates a report Excel file showing what needs to change
- You manually update SharePoint based on the report
"""
import sys
from pathlib import Path
import pandas as pd
from datetime import datetime, timedelta

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from logger import setup_logger

def get_last_month_last_day() -> str:
    """Get last day of previous month"""
    today = datetime.today()
    first_day_this_month = today.replace(day=1)
    last_day_last_month = first_day_this_month - timedelta(days=1)
    return last_day_last_month.strftime('%Y-%m-%d')

def main():
    """Main execution function"""
    
    logger = setup_logger('logs/headcount_simple.log')
    
    logger.info("=" * 70)
    logger.info("HEADCOUNT LIST AUTOMATION - SIMPLIFIED VERSION")
    logger.info("=" * 70)
    
    try:
        # Get Excel file path
        excel_file = input("Enter the full path to your Excel file: ").strip().strip('"')
        
        if not Path(excel_file).exists():
            print(f"\n❌ Error: File not found: {excel_file}")
            return 1
        
        print(f"\n✓ Found Excel file: {excel_file}")
        
        # Read both worksheets
        print("\nReading worksheets...")
        
        # Item B - Lookup File JH (the HR export)
        print("  - Loading 'Lookup File JH' (HR export data)...")
        item_b = pd.read_excel(excel_file, sheet_name='Lookup File JH')
        print(f"    ✓ Loaded {len(item_b)} rows")
        
        # Item C - Headcount List JH (the SharePoint copy in Excel)
        print("  - Loading 'Headcount List JH' (current SharePoint data)...")
        item_c = pd.read_excel(excel_file, sheet_name='Headcount List JH')
        print(f"    ✓ Loaded {len(item_c)} rows")
        
        # Filter Item B by supervisory codes
        print("\nFiltering by Supervisory Codes...")
        supervisory_codes = ['FST', 'FO/AM', 'FO/UCT']
        
        item_b_filtered = item_b[
            item_b['Supervisory Code'].astype(str).str.startswith('FST') |
            item_b['Supervisory Code'].astype(str).str.startswith('FO/AM') |
            (item_b['Supervisory Code'].astype(str) == 'FO/UCT')
        ].copy()
        
        print(f"  ✓ Filtered to {len(item_b_filtered)} records")
        
        # Normalize email addresses for comparison
        email_col = 'Email Address'
        
        if email_col not in item_b_filtered.columns or email_col not in item_c.columns:
            print(f"\n❌ Error: '{email_col}' column not found in one of the worksheets")
            return 1
        
        item_b_filtered[email_col] = item_b_filtered[email_col].astype(str).str.strip().str.lower()
        item_c[email_col] = item_c[email_col].astype(str).str.strip().str.lower()
        
        # Remove invalid emails
        item_b_filtered = item_b_filtered[
            item_b_filtered[email_col].notna() &
            (item_b_filtered[email_col] != '') &
            (item_b_filtered[email_col] != 'nan')
        ]
        
        item_c = item_c[
            item_c[email_col].notna() &
            (item_c[email_col] != '') &
            (item_c[email_col] != 'nan')
        ]
        
        # Get email sets
        emails_b = set(item_b_filtered[email_col])
        emails_c = set(item_c[email_col])
        
        print(f"\nComparison:")
        print(f"  - HR Export (Item B): {len(emails_b)} unique emails")
        print(f"  - SharePoint Copy (Item C): {len(emails_c)} unique emails")
        
        # Find differences
        emails_to_add = emails_b - emails_c
        emails_to_remove = emails_c - emails_b
        emails_common = emails_b & emails_c
        
        print(f"\nChanges needed:")
        print(f"  - Records to ADD: {len(emails_to_add)}")
        print(f"  - Records to REMOVE (mark as Left): {len(emails_to_remove)}")
        print(f"  - Records to potentially UPDATE: checking {len(emails_common)} common records...")
        
        # Prepare output dataframes
        adds_df = item_b_filtered[item_b_filtered[email_col].isin(emails_to_add)].copy()
        adds_df.insert(0, 'ACTION', 'ADD')
        
        removes_df = item_c[item_c[email_col].isin(emails_to_remove)].copy()
        removes_df.insert(0, 'ACTION', 'REMOVE')
        removes_df['Left Date'] = get_last_month_last_day()
        
        # Check for updates
        updates_list = []
        for email in emails_common:
            row_b = item_b_filtered[item_b_filtered[email_col] == email].iloc[0]
            row_c = item_c[item_c[email_col] == email].iloc[0]
            
            # Compare all common columns
            common_cols = set(row_b.index) & set(row_c.index)
            changes = {}
            
            for col in common_cols:
                if col == email_col:
                    continue
                val_b = row_b[col]
                val_c = row_c[col]
                
                # Handle NaN
                if pd.isna(val_b) and pd.isna(val_c):
                    continue
                
                if str(val_b).strip() != str(val_c).strip():
                    changes[col] = f"{val_c} → {val_b}"
            
            if changes:
                update_row = row_b.copy()
                update_row['ACTION'] = 'UPDATE'
                update_row['Changes'] = ', '.join([f"{k}: {v}" for k, v in changes.items()])
                updates_list.append(update_row)
        
        if updates_list:
            updates_df = pd.DataFrame(updates_list)
            updates_df = updates_df[['ACTION', 'Changes'] + [col for col in updates_df.columns if col not in ['ACTION', 'Changes']]]
        else:
            updates_df = pd.DataFrame()
        
        print(f"  - Records with UPDATES: {len(updates_list)}")
        
        # Create output Excel file
        output_file = f"Headcount_Changes_Report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        output_path = Path.cwd() / output_file
        
        print(f"\nGenerating report: {output_file}")
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # Summary sheet
            summary_data = {
                'Category': ['Records to ADD', 'Records to REMOVE (mark as Left)', 'Records to UPDATE', 'Total Changes'],
                'Count': [len(adds_df), len(removes_df), len(updates_list), len(adds_df) + len(removes_df) + len(updates_list)]
            }
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Details sheets
            if not adds_df.empty:
                adds_df.to_excel(writer, sheet_name='1_To_Add', index=False)
            
            if not removes_df.empty:
                removes_df.to_excel(writer, sheet_name='2_To_Remove', index=False)
            
            if not updates_df.empty:
                updates_df.to_excel(writer, sheet_name='3_To_Update', index=False)
        
        print(f"\n✅ SUCCESS! Report generated: {output_path}")
        print("\nNext steps:")
        print("1. Open the Excel report")
        print("2. Review the changes")
        print("3. Manually update SharePoint based on the report")
        print("   - ADD tab: Add these records to SharePoint")
        print("   - REMOVE tab: Mark these as 'Left' with the date shown")
        print("   - UPDATE tab: Update the fields that changed")
        
        logger.info(f"Report generated: {output_path}")
        logger.info(f"Adds: {len(adds_df)}, Removes: {len(removes_df)}, Updates: {len(updates_list)}")
        
        return 0
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        logger.error(f"Error: {str(e)}")
        logger.exception("Full traceback:")
        return 1

if __name__ == "__main__":
    exit_code = main()
    input("\nPress Enter to close...")
    sys.exit(exit_code)
