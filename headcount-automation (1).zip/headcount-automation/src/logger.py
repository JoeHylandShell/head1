"""
Logging configuration for Headcount List Automation
"""
import logging
from pathlib import Path
from datetime import datetime

def setup_logger(log_path: str) -> logging.Logger:
    """
    Setup logging configuration with both file and console handlers
    
    Args:
        log_path: Path to the log file
        
    Returns:
        Configured logger instance
    """
    # Create logs directory if it doesn't exist
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    
    # Create logger
    logger = logging.getLogger('headcount_automation')
    logger.setLevel(logging.INFO)
    
    # Remove existing handlers to avoid duplicates
    logger.handlers.clear()
    
    # File handler
    fh = logging.FileHandler(log_path)
    fh.setLevel(logging.INFO)
    
    # Console handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    
    # Add handlers to logger
    logger.addHandler(fh)
    logger.addHandler(ch)
    
    return logger

def log_change_summary(logger: logging.Logger, adds: int, updates: int, removes: int):
    """
    Log a summary of changes made
    
    Args:
        logger: Logger instance
        adds: Number of records added
        updates: Number of records updated
        removes: Number of records removed
    """
    logger.info("=" * 60)
    logger.info("CHANGE SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Records Added:   {adds}")
    logger.info(f"Records Updated: {updates}")
    logger.info(f"Records Removed: {removes}")
    logger.info(f"Total Changes:   {adds + updates + removes}")
    logger.info("=" * 60)
