"""
SharePoint handler for reading and writing to Headcount List (Item A)
"""
from office365.runtime.auth.user_credential import UserCredential
from office365.sharepoint.client_context import ClientContext
from office365.sharepoint.listitems.listitem import ListItem
import pandas as pd
from typing import List, Dict, Optional
from config import Config

class SharePointHandler:
    """Handler for SharePoint list operations"""
    
    def __init__(self):
        """Initialize SharePoint connection"""
        try:
            if Config.USE_COOKIES:
                print("Using cookie-based authentication...")
                if not Config.FEDAUTH_COOKIE or not Config.RTFA_COOKIE:
                    raise Exception("Cookie authentication enabled but FEDAUTH_COOKIE or RTFA_COOKIE not set in .env")
                
                # Use cookie-based authentication
                from office365.runtime.auth.authentication_context import AuthenticationContext
                self.ctx = ClientContext(Config.SHAREPOINT_URL)
                
                # Set cookies manually
                self.ctx.request_cookies = {
                    'FedAuth': Config.FEDAUTH_COOKIE,
                    'rtFa': Config.RTFA_COOKIE
                }
                
                print("Cookies set, testing connection...")
            else:
                # Check if credentials are set
                if not Config.SHAREPOINT_USERNAME or Config.SHAREPOINT_USERNAME == 'your_email@shell.com':
                    raise Exception("SHAREPOINT_USERNAME not configured in .env file")
                if not Config.SHAREPOINT_PASSWORD or Config.SHAREPOINT_PASSWORD == 'your_password':
                    raise Exception("SHAREPOINT_PASSWORD not configured in .env file")
                if not Config.SHAREPOINT_URL or 'yourcompany' in Config.SHAREPOINT_URL:
                    raise Exception("SHAREPOINT_URL not configured in .env file")
                
                print(f"Attempting to connect to SharePoint as {Config.SHAREPOINT_USERNAME}...")
                
                credentials = UserCredential(
                    Config.SHAREPOINT_USERNAME,
                    Config.SHAREPOINT_PASSWORD
                )
                self.ctx = ClientContext(Config.SHAREPOINT_URL).with_credentials(credentials)
            
            self.list_title = Config.HEADCOUNT_LIST_NAME
            
            # Test the connection
            web = self.ctx.web
            self.ctx.load(web)
            self.ctx.execute_query()
            
            print(f"SharePoint connection successful! Connected to: {web.properties.get('Title', 'SharePoint')}")
        except Exception as e:
            error_msg = str(e)
            if 'authentication' in error_msg.lower() or 'credentials' in error_msg.lower():
                raise Exception(f"Authentication failed. Please check your credentials or cookies in .env file. Error: {error_msg}")
            elif 'site' in error_msg.lower() or 'url' in error_msg.lower():
                raise Exception(f"Could not connect to SharePoint URL. Please check SHAREPOINT_URL in .env file. Error: {error_msg}")
            else:
                raise Exception(f"Failed to initialize SharePoint connection: {error_msg}")
    
    def get_all_items(self) -> pd.DataFrame:
        """
        Fetch all items from SharePoint Headcount List (Item A)
        
        Returns:
            DataFrame containing all SharePoint list items
            
        Raises:
            Exception: If items cannot be fetched
        """
        try:
            sp_list = self.ctx.web.lists.get_by_title(self.list_title)
            items = sp_list.items.get().execute_query()
            
            # Convert to DataFrame
            data = []
            for item in items:
                data.append(item.properties)
            
            df = pd.DataFrame(data)
            
            # Normalize email addresses for matching
            if Config.UNIQUE_KEY_COLUMN in df.columns:
                df[Config.UNIQUE_KEY_COLUMN] = (
                    df[Config.UNIQUE_KEY_COLUMN]
                    .astype(str)
                    .str.strip()
                    .str.lower()
                )
            
            print(f"Fetched {len(df)} items from SharePoint")
            return df
        
        except Exception as e:
            raise Exception(f"Failed to fetch SharePoint items: {str(e)}")
    
    def add_item(self, item_data: Dict) -> bool:
        """
        Add new item to SharePoint list
        
        Args:
            item_data: Dictionary containing item properties
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if Config.DRY_RUN:
                print(f"[DRY RUN] Would add item: {item_data.get(Config.UNIQUE_KEY_COLUMN)}")
                return True
            
            sp_list = self.ctx.web.lists.get_by_title(self.list_title)
            
            # Clean the data - remove any pandas/numpy types
            clean_data = {}
            for key, value in item_data.items():
                if pd.notna(value):
                    # Convert numpy/pandas types to native Python types
                    if hasattr(value, 'item'):
                        clean_data[key] = value.item()
                    else:
                        clean_data[key] = value
            
            new_item = sp_list.add_item(clean_data)
            self.ctx.execute_query()
            return True
            
        except Exception as e:
            print(f"Error adding item: {str(e)}")
            return False
    
    def update_item(self, item_id: int, update_data: Dict) -> bool:
        """
        Update existing item in SharePoint list
        
        Args:
            item_id: SharePoint item ID
            update_data: Dictionary containing fields to update
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if Config.DRY_RUN:
                print(f"[DRY RUN] Would update item {item_id}: {update_data.get(Config.UNIQUE_KEY_COLUMN)}")
                return True
            
            sp_list = self.ctx.web.lists.get_by_title(self.list_title)
            item = sp_list.get_item_by_id(item_id)
            
            # Update each field
            for key, value in update_data.items():
                if key != 'ID' and pd.notna(value):
                    # Convert numpy/pandas types to native Python types
                    if hasattr(value, 'item'):
                        item.set_property(key, value.item())
                    else:
                        item.set_property(key, value)
            
            item.update()
            self.ctx.execute_query()
            return True
            
        except Exception as e:
            print(f"Error updating item {item_id}: {str(e)}")
            return False
    
    def mark_as_left(self, item_id: int, last_day: str, email: str) -> bool:
        """
        Mark employee as left by updating 'Left' column with last day of previous month
        
        Args:
            item_id: SharePoint item ID
            last_day: Last day date string
            email: Email address for logging
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if Config.DRY_RUN:
                print(f"[DRY RUN] Would mark as left: {email} (Last day: {last_day})")
                return True
            
            return self.update_item(item_id, {'Left': last_day})
            
        except Exception as e:
            print(f"Error marking item {item_id} as left: {str(e)}")
            return False
    
    def get_list_columns(self) -> List[str]:
        """
        Get list of column names from SharePoint list
        
        Returns:
            List of column names
        """
        try:
            sp_list = self.ctx.web.lists.get_by_title(self.list_title)
            fields = sp_list.fields.get().execute_query()
            
            column_names = [field.properties['Title'] for field in fields]
            return column_names
            
        except Exception as e:
            raise Exception(f"Failed to get list columns: {str(e)}")
