"""
Configuration file for Headcount List Automation
"""
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Configuration class containing all settings"""
    
    # SharePoint credentials
    SHAREPOINT_URL = os.getenv('SHAREPOINT_URL')
    SHAREPOINT_USERNAME = os.getenv('SHAREPOINT_USERNAME')
    SHAREPOINT_PASSWORD = os.getenv('SHAREPOINT_PASSWORD')
    
    # Cookie-based authentication (easier with MFA)
    # Set USE_COOKIES = True to use browser cookies instead of username/password
    USE_COOKIES = os.getenv('USE_COOKIES', 'False').lower() == 'true'
    FEDAUTH_COOKIE = os.getenv('FEDAUTH_COOKIE', '')
    RTFA_COOKIE = os.getenv('RTFA_COOKIE', '')
    
    # SharePoint list details
    HEADCOUNT_LIST_NAME = "Headcount List"  # Item A
    HEADCOUNT_LIST_URL = os.getenv('HEADCOUNT_LIST_URL')
    
    # Excel file paths
    LOOKUP_FILE_PATH = os.getenv('LOOKUP_FILE_PATH')  # Item B location
    WORKSHEET_NAME = "Lookup File JH"
    
    # Business rules - Supervisory Code filtering
    # Records with codes that:
    # - Start with "FST" (e.g., FST, FST/L, FST/LE, FST/LMO, FST/L(+))
    # - Start with "FO/AM" (e.g., FO/AM, FO/AME, FO/AMD, FO/AM(+))
    # - Exactly equal "FO/UCT" (not FO/UCT/anything else)
    
    # NOTE: We'll use filtering logic in excel_handler.py, not a simple list
    SUPERVISORY_CODE_COLUMN = 'Supervisory Code'
    
    UNIQUE_KEY_COLUMN = 'Email Address'  # Column N - the unique identifier
    
    # Logging
    LOG_FILE_PATH = 'logs/headcount_sync.log'
    
    # Dry run mode (set to True to test without making changes)
    DRY_RUN = False
