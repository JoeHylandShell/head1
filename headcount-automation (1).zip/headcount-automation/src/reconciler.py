"""
Reconciliation engine for comparing SharePoint and Excel data
"""
import pandas as pd
from typing import Tuple, List, Dict
from datetime import datetime, timedelta
from config import Config

class HeadcountReconciler:
    """Core reconciliation logic for headcount list automation"""
    
    def __init__(self):
        """Initialize reconciler with unique key from config"""
        self.unique_key = Config.UNIQUE_KEY_COLUMN
    
    def compare(
        self,
        item_a: pd.DataFrame,  # SharePoint data
        item_b: pd.DataFrame   # Excel lookup file
    ) -> Tuple[List[Dict], List[Dict], List[Dict]]:
        """
        Compare Item A (SharePoint) and Item B (Excel) to identify:
        - Records to add (in B but not in A)
        - Records to update (in both but fields differ)
        - Records to remove (in A but not in B, mark as Left)
        
        Args:
            item_a: DataFrame from SharePoint (Headcount List)
            item_b: DataFrame from Excel (Lookup File JH)
            
        Returns:
            Tuple of (adds, updates, removes) as lists of dictionaries
        """
        
        print("\n" + "=" * 60)
        print("RECONCILIATION ANALYSIS")
        print("=" * 60)
        
        # Ensure email columns exist
        if self.unique_key not in item_a.columns:
            raise ValueError(f"Column '{self.unique_key}' not found in SharePoint data")
        if self.unique_key not in item_b.columns:
            raise ValueError(f"Column '{self.unique_key}' not found in Excel data")
        
        # Normalize email keys (should already be done but ensure)
        item_a[self.unique_key] = item_a[self.unique_key].astype(str).str.strip().str.lower()
        item_b[self.unique_key] = item_b[self.unique_key].astype(str).str.strip().str.lower()
        
        # Remove any NaN or empty emails
        item_a = item_a[
            item_a[self.unique_key].notna() & 
            (item_a[self.unique_key] != '') &
            (item_a[self.unique_key] != 'nan')
        ]
        item_b = item_b[
            item_b[self.unique_key].notna() & 
            (item_b[self.unique_key] != '') &
            (item_b[self.unique_key] != 'nan')
        ]
        
        # Get email sets
        emails_a = set(item_a[self.unique_key])
        emails_b = set(item_b[self.unique_key])
        
        print(f"SharePoint records: {len(emails_a)}")
        print(f"Excel records: {len(emails_b)}")
        
        # 1. ADDS: In B but not in A (completely new records)
        emails_to_add = emails_b - emails_a
        adds = item_b[item_b[self.unique_key].isin(emails_to_add)].to_dict('records')
        print(f"\nRecords to ADD: {len(adds)}")
        if adds:
            for add in adds[:5]:  # Show first 5
                print(f"  - {add.get(self.unique_key)}")
            if len(adds) > 5:
                print(f"  ... and {len(adds) - 5} more")
        
        # 2. REMOVES: In A but not in B (mark with last day of previous month)
        emails_to_remove = emails_a - emails_b
        removes = item_a[item_a[self.unique_key].isin(emails_to_remove)].to_dict('records')
        
        # Add "Left" date (last day of previous month)
        last_month_last_day = self._get_last_month_last_day()
        for record in removes:
            record['Left'] = last_month_last_day
        
        print(f"\nRecords to REMOVE (mark as left): {len(removes)}")
        if removes:
            for remove in removes[:5]:  # Show first 5
                print(f"  - {remove.get(self.unique_key)} (Left date: {last_month_last_day})")
            if len(removes) > 5:
                print(f"  ... and {len(removes) - 5} more")
        
        # 3. UPDATES: In both but fields differ
        emails_common = emails_a & emails_b
        updates = []
        
        print(f"\nAnalyzing {len(emails_common)} common records for updates...")
        
        for email in emails_common:
            row_a = item_a[item_a[self.unique_key] == email].iloc[0]
            row_b = item_b[item_b[self.unique_key] == email].iloc[0]
            
            # Compare all fields that exist in both
            changes = {}
            common_columns = set(row_a.index) & set(row_b.index)
            
            for col in common_columns:
                if col == 'ID':  # Skip ID field
                    continue
                
                val_a = row_a[col]
                val_b = row_b[col]
                
                # Handle NaN comparisons
                if pd.isna(val_a) and pd.isna(val_b):
                    continue
                
                # Convert to strings for comparison if not numeric
                try:
                    if val_a != val_b:
                        changes[col] = val_b
                except:
                    # If comparison fails, convert to string
                    if str(val_a) != str(val_b):
                        changes[col] = val_b
            
            if changes:
                changes['ID'] = row_a.get('ID')  # SharePoint item ID for updating
                changes[self.unique_key] = email
                updates.append(changes)
        
        print(f"\nRecords to UPDATE: {len(updates)}")
        if updates:
            for update in updates[:5]:  # Show first 5
                changed_fields = [k for k in update.keys() if k not in ['ID', self.unique_key]]
                print(f"  - {update.get(self.unique_key)}: {', '.join(changed_fields)}")
            if len(updates) > 5:
                print(f"  ... and {len(updates) - 5} more")
        
        print("=" * 60 + "\n")
        
        return adds, updates, removes
    
    def _get_last_month_last_day(self) -> str:
        """
        Get last day of previous month in ISO format (YYYY-MM-DD)
        
        Returns:
            Date string in ISO format
        """
        today = datetime.today()
        # Get first day of current month
        first_day_this_month = today.replace(day=1)
        # Subtract one day to get last day of previous month
        last_day_last_month = first_day_this_month - timedelta(days=1)
        return last_day_last_month.strftime('%Y-%m-%d')
    
    def validate_data(self, df: pd.DataFrame, source_name: str) -> bool:
        """
        Validate that required columns exist in the DataFrame
        
        Args:
            df: DataFrame to validate
            source_name: Name of the data source for error messages
            
        Returns:
            True if valid, raises exception otherwise
        """
        if df is None or df.empty:
            raise ValueError(f"{source_name} data is empty or None")
        
        if self.unique_key not in df.columns:
            raise ValueError(f"Required column '{self.unique_key}' not found in {source_name}")
        
        return True
