"""
Excel file handler for reading Lookup File JH (Item B)
"""
import pandas as pd
from typing import Optional
from config import Config

class ExcelHandler:
    """Handler for reading and processing Excel lookup files"""
    
    def __init__(self, file_path: Optional[str] = None):
        """
        Initialize Excel handler
        
        Args:
            file_path: Path to Excel file (uses config default if not provided)
        """
        self.file_path = file_path or Config.LOOKUP_FILE_PATH
    
    def read_lookup_file(self) -> pd.DataFrame:
        """
        Read Item B (Lookup File JH) from Excel workbook
        
        Returns:
            DataFrame containing filtered records based on supervisory codes
            
        Raises:
            Exception: If file cannot be read or processed
        """
        try:
            # Read Excel file
            df = pd.read_excel(
                self.file_path,
                sheet_name=Config.WORKSHEET_NAME,
                engine='openpyxl'
            )
            
            print(f"Loaded {len(df)} total records from Excel")
            
            # Filter by supervisory codes using the business rules:
            # - Starts with "FST"
            # - Starts with "FO/AM"
            # - Exactly equals "FO/UCT" (not FO/UCT/something)
            if Config.SUPERVISORY_CODE_COLUMN in df.columns:
                df_filtered = df[
                    df[Config.SUPERVISORY_CODE_COLUMN].astype(str).str.startswith('FST') |
                    df[Config.SUPERVISORY_CODE_COLUMN].astype(str).str.startswith('FO/AM') |
                    (df[Config.SUPERVISORY_CODE_COLUMN].astype(str) == 'FO/UCT')
                ].copy()
                print(f"Filtered to {len(df_filtered)} records matching supervisory codes")
                print(f"  - FST*: {len(df[df[Config.SUPERVISORY_CODE_COLUMN].astype(str).str.startswith('FST')])}")
                print(f"  - FO/AM*: {len(df[df[Config.SUPERVISORY_CODE_COLUMN].astype(str).str.startswith('FO/AM')])}")
                print(f"  - FO/UCT (exact): {len(df[df[Config.SUPERVISORY_CODE_COLUMN].astype(str) == 'FO/UCT'])}")
            else:
                print(f"Warning: '{Config.SUPERVISORY_CODE_COLUMN}' column not found, using all records")
                df_filtered = df.copy()
            
            # Clean email addresses (Column N) - normalize for matching
            if Config.UNIQUE_KEY_COLUMN in df_filtered.columns:
                df_filtered[Config.UNIQUE_KEY_COLUMN] = (
                    df_filtered[Config.UNIQUE_KEY_COLUMN]
                    .astype(str)
                    .str.strip()
                    .str.lower()
                )
            else:
                raise ValueError(f"Column '{Config.UNIQUE_KEY_COLUMN}' not found in Excel file")
            
            # Remove any rows where email is null or empty
            df_filtered = df_filtered[
                df_filtered[Config.UNIQUE_KEY_COLUMN].notna() &
                (df_filtered[Config.UNIQUE_KEY_COLUMN] != '') &
                (df_filtered[Config.UNIQUE_KEY_COLUMN] != 'nan')
            ]
            
            print(f"Final record count after cleaning: {len(df_filtered)}")
            
            return df_filtered
        
        except FileNotFoundError:
            raise Exception(f"Excel file not found: {self.file_path}")
        except Exception as e:
            raise Exception(f"Failed to read Excel file: {str(e)}")
    
    def get_column_names(self) -> list:
        """
        Get list of column names from the Excel file
        
        Returns:
            List of column names
        """
        try:
            df = pd.read_excel(
                self.file_path,
                sheet_name=Config.WORKSHEET_NAME,
                nrows=0,
                engine='openpyxl'
            )
            return df.columns.tolist()
        except Exception as e:
            raise Exception(f"Failed to read column names: {str(e)}")
