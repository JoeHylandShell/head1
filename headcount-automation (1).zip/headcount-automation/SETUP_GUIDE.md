# Setup Guide - Headcount List Automation

Quick start guide for first-time setup.

## Step-by-Step Setup

### 1. Extract Files

Extract the zip file to your desired location, for example:
- Windows: `C:\Projects\headcount-automation`
- Mac/Linux: `~/projects/headcount-automation`

### 2. Install Python

Ensure Python 3.8+ is installed:

```bash
python --version
```

If not installed, download from: https://www.python.org/downloads/

### 3. Create Virtual Environment

Open terminal/command prompt in the project folder:

```bash
# Create virtual environment
python -m venv venv

# Activate it
# Windows:
venv\Scripts\activate

# Mac/Linux:
source venv/bin/activate
```

You should see `(venv)` in your terminal prompt.

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

This will install:
- Office365-REST-Python-Client (SharePoint)
- pandas (data processing)
- openpyxl (Excel files)
- python-dotenv (configuration)

### 5. Configure Credentials

Copy the template:

```bash
# Windows
copy .env.template .env

# Mac/Linux
cp .env.template .env
```

Edit `.env` with a text editor (Notepad, VSCode, etc.):

```env
SHAREPOINT_URL=https://shell.sharepoint.com
SHAREPOINT_USERNAME=joseph.hyland@shell.com
SHAREPOINT_PASSWORD=your_actual_password

HEADCOUNT_LIST_URL=https://shell.sharepoint.com/sites/risk/Lists/HeadcountList

LOOKUP_FILE_PATH=C:/Users/YourName/Documents/Headcount List - Reconciliation File from Apr 2025.xlsx
```

**Important**: Use forward slashes (/) in file paths, even on Windows!

### 6. Test Connections

Test SharePoint:

```bash
python -c "from src.sharepoint import SharePointHandler; sp = SharePointHandler(); print('SharePoint connection successful!')"
```

Test Excel file:

```bash
python -c "from src.excel_handler import ExcelHandler; ex = ExcelHandler(); df = ex.read_lookup_file(); print(f'Excel file loaded: {len(df)} records')"
```

### 7. First Run (Dry Run)

For safety, do a dry run first:

1. Edit `src/config.py`
2. Set `DRY_RUN = True`
3. Run:

```bash
python main.py
```

This shows what changes would be made without actually modifying SharePoint.

### 8. Review Logs

Check the output:

```bash
# Windows
type logs\headcount_sync.log

# Mac/Linux
cat logs/headcount_sync.log
```

### 9. Production Run

If the dry run looks good:

1. Edit `src/config.py`
2. Set `DRY_RUN = False`
3. Run:

```bash
python main.py
```

## Common Issues

### "Module not found" errors

Ensure virtual environment is activated:

```bash
# Check if (venv) appears in prompt
# If not:
# Windows: venv\Scripts\activate
# Mac/Linux: source venv/bin/activate

# Then reinstall:
pip install -r requirements.txt
```

### "File not found" - Excel file

Check your `.env` file:
- Use **forward slashes** even on Windows
- Use **full path**, not relative
- Example: `C:/Users/joe/Documents/file.xlsx`

### SharePoint authentication fails

Try:
- Verify username/password are correct
- Ensure you're on Shell network (VPN if remote)
- Check if MFA is required (may need app password)

### Permission denied on SharePoint

Verify you have "Edit items" permission:
1. Open SharePoint list in browser
2. Check if you can manually edit items
3. Contact SharePoint admin if needed

## Quick Commands

### Run automation

```bash
# Windows
run_automation.bat

# Mac/Linux
./run_automation.sh
```

### View logs

```bash
# Latest log
# Windows: type logs\headcount_sync.log
# Mac/Linux: cat logs/headcount_sync.log

# Follow live (Mac/Linux only)
tail -f logs/headcount_sync.log
```

### Update dependencies

```bash
pip install --upgrade -r requirements.txt
```

## Next Steps

Once setup is complete:

1. ✅ Schedule monthly runs (see README.md)
2. ✅ Set up email notifications (optional)
3. ✅ Document for team handover
4. ✅ Add to team runbooks

## Support

Contact:
- **Developer**: Joseph Hyland (joseph.hyland@shell.com)
- **Manager**: Sajad Bhatti (Mike)
- **Team**: Governance Risk - Market Risk Analytics
