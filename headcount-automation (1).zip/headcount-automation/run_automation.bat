@echo off
REM Headcount List Automation - Windows Run Script

echo ============================================
echo Headcount List Automation
echo ============================================
echo.

REM Activate virtual environment
if exist venv\Scripts\activate.bat (
    call venv\Scripts\activate.bat
    echo Virtual environment activated
) else (
    echo Warning: Virtual environment not found
    echo Please run: python -m venv venv
    echo.
)

REM Run the automation
echo Running automation...
echo.
python main.py

REM Check exit code
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ============================================
    echo Automation completed successfully!
    echo ============================================
) else (
    echo.
    echo ============================================
    echo Automation failed with errors
    echo Check logs/headcount_sync.log for details
    echo ============================================
)

echo.
pause
