"""
Headcount List Automation - Main Entry Point

This script automates the synchronization between:
- SharePoint Headcount List (Item A)
- Excel Lookup File JH (Item B)

Business Logic:
1. Add new records from Item B to Item A
2. Update existing records when fields change
3. Mark records as "Left" when they no longer appear in Item B
"""
import sys
from pathlib import Path

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from sharepoint import SharePointHandler
from excel_handler import ExcelHandler
from reconciler import HeadcountReconciler
from logger import setup_logger, log_change_summary
from config import Config

def main():
    """Main execution function"""
    
    # Setup logging
    logger = setup_logger(Config.LOG_FILE_PATH)
    
    logger.info("=" * 70)
    logger.info("HEADCOUNT LIST AUTOMATION - STARTED")
    logger.info("=" * 70)
    
    if Config.DRY_RUN:
        logger.info("*** DRY RUN MODE - NO CHANGES WILL BE MADE ***")
    
    try:
        # 1. Initialize handlers
        logger.info("Initializing handlers...")
        sp_handler = SharePointHandler()
        excel_handler = ExcelHandler()
        reconciler = HeadcountReconciler()
        
        # 2. Load data from SharePoint (Item A)
        logger.info("\nLoading SharePoint data (Item A - Headcount List)...")
        item_a = sp_handler.get_all_items()
        logger.info(f"Loaded {len(item_a)} records from SharePoint")
        
        # Validate SharePoint data
        reconciler.validate_data(item_a, "SharePoint")
        
        # 3. Load data from Excel (Item B)
        logger.info("\nLoading Excel lookup file (Item B - Lookup File JH)...")
        item_b = excel_handler.read_lookup_file()
        logger.info(f"Loaded {len(item_b)} records from Excel (after filtering)")
        
        # Validate Excel data
        reconciler.validate_data(item_b, "Excel")
        
        # 4. Perform reconciliation
        logger.info("\nPerforming reconciliation...")
        adds, updates, removes = reconciler.compare(item_a, item_b)
        
        logger.info(f"\nReconciliation complete:")
        logger.info(f"  - Records to add: {len(adds)}")
        logger.info(f"  - Records to update: {len(updates)}")
        logger.info(f"  - Records to mark as left: {len(removes)}")
        
        # 5. Apply changes to SharePoint
        if not Config.DRY_RUN:
            logger.info("\nApplying changes to SharePoint...")
        else:
            logger.info("\nSimulating changes (DRY RUN MODE)...")
        
        add_count = 0
        update_count = 0
        remove_count = 0
        
        # ADDS - New records from Excel
        if adds:
            logger.info(f"\nAdding {len(adds)} new records...")
            for record in adds:
                email = record.get(Config.UNIQUE_KEY_COLUMN, 'Unknown')
                if sp_handler.add_item(record):
                    logger.info(f"  ✓ Added: {email}")
                    add_count += 1
                else:
                    logger.error(f"  ✗ Failed to add: {email}")
        
        # UPDATES - Changed fields
        if updates:
            logger.info(f"\nUpdating {len(updates)} existing records...")
            for record in updates:
                item_id = record.pop('ID', None)
                email = record.get(Config.UNIQUE_KEY_COLUMN, 'Unknown')
                
                if item_id is not None:
                    changed_fields = [k for k in record.keys() if k != Config.UNIQUE_KEY_COLUMN]
                    if sp_handler.update_item(item_id, record):
                        logger.info(f"  ✓ Updated: {email} (Fields: {', '.join(changed_fields)})")
                        update_count += 1
                    else:
                        logger.error(f"  ✗ Failed to update: {email}")
                else:
                    logger.error(f"  ✗ No ID found for: {email}")
        
        # REMOVES - Mark as left
        if removes:
            logger.info(f"\nMarking {len(removes)} records as left...")
            for record in removes:
                item_id = record.get('ID')
                left_date = record.get('Left')
                email = record.get(Config.UNIQUE_KEY_COLUMN, 'Unknown')
                
                if item_id is not None:
                    if sp_handler.mark_as_left(item_id, left_date, email):
                        logger.info(f"  ✓ Marked as left: {email} (Date: {left_date})")
                        remove_count += 1
                    else:
                        logger.error(f"  ✗ Failed to mark as left: {email}")
                else:
                    logger.error(f"  ✗ No ID found for: {email}")
        
        # 6. Log summary
        logger.info("\n")
        log_change_summary(logger, add_count, update_count, remove_count)
        
        logger.info("\n" + "=" * 70)
        logger.info("HEADCOUNT LIST AUTOMATION - COMPLETED SUCCESSFULLY")
        logger.info("=" * 70)
        
        return 0
        
    except FileNotFoundError as e:
        logger.error(f"\nFile not found: {str(e)}")
        logger.error("Please check the LOOKUP_FILE_PATH in your .env file")
        return 1
        
    except ValueError as e:
        logger.error(f"\nValidation error: {str(e)}")
        return 1
        
    except Exception as e:
        logger.error(f"\nAutomation failed with error: {str(e)}")
        logger.exception("Full traceback:")
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)
