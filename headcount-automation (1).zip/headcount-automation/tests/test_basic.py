"""
Sample tests for Headcount List Automation

Run with: pytest tests/
"""
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

def test_config_loads():
    """Test that configuration loads properly"""
    from config import Config
    assert Config.UNIQUE_KEY_COLUMN == 'Email Address'
    assert len(Config.SUPERVISORY_CODES) > 0

def test_reconciler_initialization():
    """Test reconciler can be initialized"""
    from reconciler import HeadcountReconciler
    reconciler = HeadcountReconciler()
    assert reconciler.unique_key == 'Email Address'

# Add more tests as needed
