# Headcount List Automation

Automated synchronization system for Shell's Headcount List, reconciling SharePoint data with monthly HR exports.

## Overview

This Python application automates the synchronization between:
- **Item A**: SharePoint Headcount List
- **Item B**: Excel "Lookup File JH" worksheet (monthly HR export)

### Business Logic

1. **Add**: New records from Item B are automatically added to Item A
2. **Update**: Changed fields in Item B are updated in Item A (email is the unique key)
3. **Remove**: Records in Item A that no longer appear in Item B are marked with "Left" date (last day of previous month)

### Scope

Only processes records with specific Supervisory Codes:
- **FST*** - Any code starting with "FST" (FST, FST/L, FST/LE, FST/LMO, FST/L(+), etc.)
  - Includes employees rolling up to Fiona Grandison (CRO)
- **FO/AM*** - Any code starting with "FO/AM" (FO/AM, FO/AME, FO/AMD, FO/AM(+), etc.)
  - Includes employees rolling up to Rejoice John (Global Market Risk Manager)
- **FO/UCT** - Exactly "FO/UCT" only (NOT FO/UCT/anything)
  - Employees rolling up to Bryan Khriz Acosta (Process Manager, Credit Risk, Global T&S)

**Important**: FO/UCT must be an exact match - variations like "FO/UCT/XX" are excluded.

## Project Structure

```
headcount-automation/
├── src/
│   ├── __init__.py
│   ├── config.py           # Configuration and constants
│   ├── sharepoint.py       # SharePoint operations
│   ├── excel_handler.py    # Excel file operations
│   ├── reconciler.py       # Core comparison logic
│   └── logger.py           # Audit logging
├── tests/
│   └── __init__.py
├── logs/                    # Generated log files
├── .env                     # Credentials (not in repo)
├── .env.template           # Template for credentials
├── .gitignore
├── requirements.txt
├── main.py                 # Entry point
└── README.md
```

## Setup Instructions

### 1. Prerequisites

- Python 3.8 or higher
- Access to Shell SharePoint with edit permissions on Headcount List
- Access to the monthly HR export Excel file

### 2. Installation

```bash
# Clone/extract the project
cd headcount-automation

# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Configuration

Copy the template and create your `.env` file:

```bash
cp .env.template .env
```

Edit `.env` with your credentials:

```env
# SharePoint Configuration
SHAREPOINT_URL=https://shell.sharepoint.com
SHAREPOINT_USERNAME=your.email@shell.com
SHAREPOINT_PASSWORD=your_password

# SharePoint List Details
HEADCOUNT_LIST_URL=https://shell.sharepoint.com/sites/yoursite/Lists/HeadcountList

# Excel File Path (Item B - Lookup File)
LOOKUP_FILE_PATH=C:/path/to/Headcount List - Reconciliation File from Apr 2025.xlsx
```

### 4. Test Connection

Before running the full automation, test your connections:

```python
# Test SharePoint connection
python -c "from src.sharepoint import SharePointHandler; sp = SharePointHandler(); print('Connected!')"

# Test Excel file reading
python -c "from src.excel_handler import ExcelHandler; ex = ExcelHandler(); df = ex.read_lookup_file(); print(f'Loaded {len(df)} records')"
```

## Usage

### Standard Run

```bash
python main.py
```

This will:
1. Load data from SharePoint (Item A)
2. Load data from Excel (Item B)
3. Compare and identify changes
4. Apply changes to SharePoint
5. Generate detailed logs in `logs/headcount_sync.log`

### Dry Run Mode

To test without making actual changes:

1. Edit `src/config.py`
2. Set `DRY_RUN = True`
3. Run `python main.py`

This will show what changes would be made without actually modifying SharePoint.

## Key Features

### Unique Key Matching
- Uses **Email Address** (Column N) as the unique identifier
- Email addresses are normalized (lowercase, trimmed) for matching

### Automatic Date Handling
- Records marked as "Left" receive the last day of the previous month
- Example: If run on January 28, 2026, left date will be December 31, 2025

### Comprehensive Logging
- All changes are logged with timestamps
- Logs stored in `logs/headcount_sync.log`
- Includes summary of adds/updates/removes

### Error Handling
- Validates data before processing
- Gracefully handles missing columns or files
- Continues processing even if individual updates fail

## Configuration Options

Edit `src/config.py` to customize:

```python
# Dry run mode (no actual changes)
DRY_RUN = False

# Supervisory code filtering
# Logic: startswith('FST') OR startswith('FO/AM') OR equals('FO/UCT')
SUPERVISORY_CODE_COLUMN = 'Supervisory Code'

# Unique identifier column
UNIQUE_KEY_COLUMN = 'Email Address'

# Log file location
LOG_FILE_PATH = 'logs/headcount_sync.log'
```

## Troubleshooting

### "File not found" error
- Check the `LOOKUP_FILE_PATH` in your `.env` file
- Ensure the path uses forward slashes or double backslashes
- Verify the file exists and is accessible

### SharePoint connection fails
- Verify your credentials in `.env`
- Check if your account has edit permissions on the list
- Ensure you're connected to the Shell network (VPN if remote)

### Column not found errors
- Check that column names in Excel match expected names
- Verify "Email Address" column exists in both sources
- Ensure "Supervisory Code" column exists in Excel

### No changes detected
- Verify the Excel file is the latest version
- Check that records have valid Supervisory Codes
- Run in DRY_RUN mode to see detailed analysis

## Scheduling

### Windows Task Scheduler

Create a batch file `run_automation.bat`:

```batch
@echo off
cd C:\path\to\headcount-automation
call venv\Scripts\activate
python main.py
pause
```

Schedule in Task Scheduler:
1. Open Task Scheduler
2. Create Basic Task
3. Set trigger (e.g., Monthly on 1st)
4. Action: Start a program
5. Program: `C:\path\to\headcount-automation\run_automation.bat`

### Linux/Mac Cron

Add to crontab (`crontab -e`):

```bash
# Run on 1st of each month at 9 AM
0 9 1 * * cd /path/to/headcount-automation && /path/to/venv/bin/python main.py
```

## Security Notes

- **Never commit `.env` file** - contains credentials
- Store credentials securely
- Regularly rotate passwords
- Use service account if available
- Review audit logs regularly

## Support

For issues or questions:
1. Check the logs in `logs/headcount_sync.log`
2. Review this README
3. Contact: Joseph Hyland (joseph.hyland@shell.com)
4. Manager: Sajad Bhatti (Mike)

## Version History

- **v1.0.0** (January 2026) - Initial release
  - SharePoint synchronization
  - Excel file processing
  - Automated reconciliation
  - Comprehensive logging

## License

Internal Shell use only - Market Risk Analytics team.
